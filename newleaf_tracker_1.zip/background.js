
chrome.runtime.onInstalled.addListener(() => {
    console.log('NewLeaf Tracker installed.');
});
