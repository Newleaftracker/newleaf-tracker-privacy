
document.getElementById('reset').addEventListener('click', () => {
    chrome.storage.sync.clear(() => {
        alert('All data reset.');
    });
});
